<?php

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();
jimport('joomla.application.component.model');

class NutritionsModelEstablec extends JModel {

    var $_id;
    var $_data;

    function __construct() {
        parent::__construct();

        $array = JRequest::getVar('cid', 0, '', 'array');
        $this->setId((int) $array[0]);
    }

    function setId($id) {
        // Set id and wipe data
        $this->_id = $id;
        $this->_data = null;
    }

    function &getData() {
        // Load the data
        if (empty($this->_data)) {
            $query = "SELECT cod_estab, desc_estab, cod_2000, tipoestab, cod_dpto, cod_prov, cod_dist, cod_disa, cod_red, cod_mic, clas, estado FROM establec WHERE cod_2000=".$this->_id;

            $this->_db->setQuery($query);
            $this->_data = $this->_db->loadObject();
        }
        if (!$this->_data) {
            $this->_data = new stdClass();
            $this->_data->cod_2000 = 0;
            $this->_data->cod_estab = NULL;
            $this->_data->desc_estab = NULL;
            $this->_data->tipoestab = NULL;
            $this->_data->cod_dpto = NULL;
            $this->_data->cod_prov = NULL;
            $this->_data->cod_dist = NULL;
            $this->_data->cod_disa = NULL;
            $this->_data->cod_red = NULL;
            $this->_data->cod_mic = NULL;
            $this->_data->clas = NULL;
            $this->_data->estado = NULL;
        }
        return $this->_data;
    }

    public function getDepartamentos() {
        $query = "SELECT id_ubigeo as value, tx_descripcion as text FROM ubigeo WHERE id_dg_nivel = '2'";
        $this->_db->setQuery($query);
        $departamentos = $this->_db->loadObjectList();
        return $departamentos;
    }

    public function getProvincias() {
        global $mainframe, $option;
        $filter_departamento = $mainframe->getUserStateFromRequest($option . '.nutritions.filter_departamento', 'filter_departamento', '0', 'int');
        $where = '';
        if ($filter_departamento > 0) {
            $where = "AND id_ubigeo_padre = '{$filter_departamento}'";
        }
        $query = "SELECT id_ubigeo as value, tx_descripcion as text FROM ubigeo WHERE id_dg_nivel = '3' {$where}";
        $this->_db->setQuery($query);
        $provincias = $this->_db->loadObjectList();
        return $provincias;
    }

    public function getDistritos() {
        global $mainframe, $option;
        $filter_provincia = $mainframe->getUserStateFromRequest($option . '.nutritions.filter_provincia', 'filter_provincia', '0', 'int');
        $where = '';
        if ($filter_provincia > 0) {
            $where = "AND id_ubigeo_padre = '{$filter_provincia}'";
        }
        $query = "SELECT id_ubigeo as value, tx_descripcion as text FROM ubigeo WHERE id_dg_nivel = '4' $where";
        $this->_db->setQuery($query);
        $distritos = $this->_db->loadObjectList();
        return $distritos;
    }

    public function store($data) {
        $row = & $this->getTable('establec', '');
        // bind it to the table
        if (!$row->bind($data)) {
            JError::raiseError(500, $this->_db->getErrorMsg());
            return false;
        }

        // Make sure the data is valid
        if (!$row->check()) {
            $this->setError($row->getError());
            return false;
        }
        // Store it in the db
        if (!$row->store()) {
            JError::raiseError(500, $this->_db->getErrorMsg());
            return false;
        }

        $data['cod_2000'] = $row->cod_2000;
        $data['fe_creacion'] = null;
        $data['fe_modificacion'] = null;

        return $row->cod_2000;
    }

    public function getEstablecimientos($name, $limit) {
        $query = "SELECT cod_2000, CONCAT_WS(' - ',DESC_DISA, DESC_RED, DESC_ESTAB,cod_2000) AS establec_name FROM 0001_geresall_renaes 
                  WHERE CONCAT_WS(' - ',DESC_DISA, DESC_RED, DESC_ESTAB,cod_2000) LIKE '%$name%' LIMIT $limit";
        $this->_db->setQuery($query);
        $results = $this->_db->loadObjectList();
        return $results;
    }

}

?>
