<?php

jimport('joomla.application.component.controller');

class NutritionsController extends JController
{
	function display()
	{
		parent::display();
	}

}
?>
